/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

$(document).ready(function () {

    // === Reset handler ===
    $("#btnReset").on("click", function () {
        $("#mt700Form")[0].reset();
        $(".toggle-section").hide();
    });

    // === Submit handler ===
    $("#btnSubmit").on("click", function (e) {
        e.preventDefault();
        if (validateMT700()) {
            $("#mt700Form").submit();
        }
    });

    // === Field 27 (Sequence of Total) auto-format "n/n" ===
    $("#_010_mf27_sequence_of_total").on("blur", function () {
        let val = $(this).val().trim();
        if (val && !/^\d\/\d$/.test(val)) {
            alert("Field 27: format harus n/n (contoh 1/1)");
            $(this).focus();
        }
    });

    // === Field 31C, 31D, 44C (Date) auto-format YYMMDD ===
    $("#_050_mf31c_date_of_issue, #_070_mf31d_date, #_250_of44c_latest_date_of_shipment")
        .on("blur", function () {
            let v = $(this).val().trim();
            if (v && !/^\d{6}$/.test(v)) {
                alert("Tanggal harus dalam format YYMMDD");
                $(this).focus();
            }
        });

    // === Field 32B (Currency, Amount) ===
    $("#_110_mf32b_amount").on("blur", function () {
        let ccy = $("#_110_mf32b_currency").val().trim();
        let amt = $(this).val().trim();
        let msg = checkAmountByCcy(ccy, amt);
        if (msg) {
            alert("Field 32B: " + msg);
            $(this).focus();
        }
    });

    // === Toggle 40E (Applicable Rules) ===
    $("#_060_mf40e_applicable_rules_code").on("change", function () {
        let val = $(this).val();
        if (val === "OTHR") {
            $("#_061_mf40e_applicable_rules_narrative").show();
        } else {
            $("#_061_mf40e_applicable_rules_narrative").hide().val("");
        }
    });

    // === Toggle 41a (Available With By) ===
    $("#_090_mf41a_option").on("change", function () {
        let opt = $(this).val();
        $("#div_41a_a, #div_41a_d").hide();
        if (opt === "A") $("#div_41a_a").show();
        if (opt === "D") $("#div_41a_d").show();
    });

    // === Toggle 42a (Drawee) ===
    $("#_120_mf42a_option").on("change", function () {
        let opt = $(this).val();
        $("#div_42a_a, #div_42a_d").hide();
        if (opt === "A") $("#div_42a_a").show();
        if (opt === "D") $("#div_42a_d").show();
    });

    // === Toggle 51a (Applicant Bank) ===
    $("#_200_mf51a_option").on("change", function () {
        let opt = $(this).val();
        $("#div_51a_a, #div_51a_d").hide();
        if (opt === "A") $("#div_51a_a").show();
        if (opt === "D") $("#div_51a_d").show();
    });

    // === Toggle 50 (Applicant) ===
    $("#_210_mf50_option").on("change", function () {
        let opt = $(this).val();
        $("#div_50a, #div_50f, #div_50k").hide();
        if (opt === "A") $("#div_50a").show();
        if (opt === "F") $("#div_50f").show();
        if (opt === "K") $("#div_50k").show();
    });

    // === Toggle 59 (Beneficiary) ===
    $("#_220_mf59_option").on("change", function () {
        let opt = $(this).val();
        $("#div_59, #div_59a, #div_59f").hide();
        if (opt === "59") $("#div_59").show();
        if (opt === "59A") $("#div_59a").show();
        if (opt === "59F") $("#div_59f").show();
    });

    // === Toggle 58a (Requested Confirmation Party) ===
    $("#_470_mf58a_option").on("change", function () {
        let opt = $(this).val();
        $("#div_58a_a, #div_58a_d").hide();
        if (opt === "A") $("#div_58a_a").show();
        if (opt === "D") $("#div_58a_d").show();
    });

    // === Toggle 53a (Reimbursing Bank) ===
    $("#_480_mf53a_option").on("change", function () {
        let opt = $(this).val();
        $("#div_53a_a, #div_53a_b, #div_53a_d").hide();
        if (opt === "A") $("#div_53a_a").show();
        if (opt === "B") $("#div_53a_b").show();
        if (opt === "D") $("#div_53a_d").show();
    });

    // === Toggle 57a (Advise Through Bank) ===
    $("#_500_mf57a_option").on("change", function () {
        let opt = $(this).val();
        $("#div_57a_a, #div_57a_b, #div_57a_d").hide();
        if (opt === "A") $("#div_57a_a").show();
        if (opt === "B") $("#div_57a_b").show();
        if (opt === "D") $("#div_57a_d").show();
    });

    // === Toggle 43P (Partial Shipments) ===
    $("#_160_of43p_partial_shipments").on("change", function () {
        let val = $(this).val();
        if (val && !["ALLOWED", "CONDITIONAL", "NOT ALLOWED"].includes(val)) {
            alert("Field 43P: harus ALLOWED / CONDITIONAL / NOT ALLOWED");
            $(this).focus();
        }
    });

    // === Toggle 43T (Transhipment) ===
    $("#_170_of43t_transhipment").on("change", function () {
        let val = $(this).val();
        if (val && !["ALLOWED", "CONDITIONAL", "NOT ALLOWED"].includes(val)) {
            alert("Field 43T: harus ALLOWED / CONDITIONAL / NOT ALLOWED");
            $(this).focus();
        }
    });

    // === Toggle 49 (Confirmation Instructions) ===
    $("#_330_mf49_confirmation_instructions").on("change", function () {
        let val = $(this).val();
        if (val && !["CONFIRM", "MAY ADD", "WITHOUT"].includes(val)) {
            alert("Field 49: harus CONFIRM / MAY ADD / WITHOUT");
            $(this).focus();
        }
    });

});


